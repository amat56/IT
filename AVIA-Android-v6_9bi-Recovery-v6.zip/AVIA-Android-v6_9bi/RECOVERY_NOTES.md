# AVIA v6.9bi Recovery v3

This package uses the complete `index.html` supplied by the user on 21 September 2026 as the web-app baseline.

## Confirmed native baseline
- Package / namespace: `my.gov.demo.myunit`
- WebView entry: `file:///android_asset/index.html`
- Native bridges: `AndroidBiometric`, `AndroidLocation`
- Deep links: `avia://invite`, `avia://reset-password`
- Permissions: INTERNET, coarse/fine location, USE_BIOMETRIC
- Java: 17
- Gradle workflow: 8.9
- Android compile/target SDK: 35
- Version name: `6.9bi`

## Recovery v3 changes
- Replaced the reconstructed HTML with the complete uploaded `index.html`.
- Standardised user-visible/current build version markers to `v6.9bi`.
- Fixed KPI inline handlers from the undefined `openKpiDetail(...)` to `openKpiDetails(...)`.
- Added hidden compatibility containers `present` and `away` because legacy render wrappers still reference them.
- Replaced an undefined `showView?.('admin')` call with the existing `show('admin')` navigation function.
- Added a `globalError` surface used by sync/error handling.
- Added an AVIA text fallback when `avia_wordmark.png` is not present in the package.
- Preserved historical localStorage key suffixes to avoid breaking existing device data/configuration.

## Static audit
- JavaScript syntax validated with `node --check`.
- No duplicate literal HTML IDs were intentionally introduced by Recovery v3.
- Several historical function definitions occur more than once (`renderAll`, `renderToday`, `renderAdmin`, `saveStatus`, etc.). These are part of the accumulated patch/wrapper architecture in the recovered source. Recovery v3 does not aggressively delete them because later definitions/wrappers intentionally override earlier behavior. Refactoring them should be a separate tested release.
- Some legacy element references are optional/guarded and no longer have corresponding UI elements (`todaySearch`, `favoriteStaffList`, `adminTrendCard`, etc.). They have been left in place where they do not create an unguarded runtime failure.

## Build validation limitation
The current execution environment does not have the Gradle CLI/Android SDK toolchain installed, so an APK was not compiled locally. The included GitHub Actions workflow is configured to build the debug APK with Java 17 and Gradle 8.9.

## Recovery v4 UI alignment
- UNIT IT/organization label centered directly below Jata Negara.
- AVIA subtitle constrained to the wordmark width and centered directly below the AVIA graphic.


## Recovery v6 header alignment
- Added a definitive CSS override after all existing header CSS.
- UNIT IT is fixed to the exact width of the Jata container and centered directly underneath it.
- AVIA subtitle is fixed to the exact width of the AVIA wordmark and centered directly underneath it.
- Uses explicit grid columns and !important overrides to prevent older accumulated CSS from retaining the previous positions.
