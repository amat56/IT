# AVIA Backup & Restore

## Source recovery
Keep the complete project ZIP and Git commit/tag for each stable release.

## APK recovery
Keep the signed release APK for every production baseline.

## Configuration recovery
Use Admin > Backup/Restore for application configuration. Configuration includes status types, quick status, dashboard preferences, session timeout and application identity.

## Database recovery
For production Supabase, use database backups/export according to the organization's operational policy. Never place the service-role key inside the Android app.

## Recommended Golden Baseline
After pilot testing passes, archive v6.9ah (or the final successor) as the immutable baseline before starting new feature development.
