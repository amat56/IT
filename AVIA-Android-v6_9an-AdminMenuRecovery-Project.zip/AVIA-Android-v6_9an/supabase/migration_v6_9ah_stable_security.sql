-- AVIA v6.9ah Stable Candidate
alter table public.profiles
  add column if not exists last_login_at timestamptz;

-- Login rate limiting remains enforced by Supabase Auth/platform controls.
-- The app also applies a temporary device-side lock after 5 failed attempts.
