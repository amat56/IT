-- AVIA v6.9k: birthday display (day/month only; no birth year)
alter table public.profiles add column if not exists birth_day smallint;
alter table public.profiles add column if not exists birth_month smallint;
alter table public.profiles add column if not exists show_birthday boolean not null default true;

alter table public.profiles drop constraint if exists profiles_birth_day_check;
alter table public.profiles add constraint profiles_birth_day_check check (birth_day is null or birth_day between 1 and 31);
alter table public.profiles drop constraint if exists profiles_birth_month_check;
alter table public.profiles add constraint profiles_birth_month_check check (birth_month is null or birth_month between 1 and 12);
