-- AVIA v6.9ai
alter table public.profiles add column if not exists invitation_status text default 'active';
