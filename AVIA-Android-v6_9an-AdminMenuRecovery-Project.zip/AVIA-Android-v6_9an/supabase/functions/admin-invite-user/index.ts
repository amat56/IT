import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(url, service);
    const bearer = (req.headers.get("Authorization") || "").replace("Bearer ", "");
    const { data: { user }, error: authErr } = await admin.auth.getUser(bearer);
    if (authErr || !user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
    const { data: caller } = await admin.from("profiles").select("role").eq("id", user.id).single();
    if (!caller || caller.role !== "admin") return new Response(JSON.stringify({ error: "Admin sahaja." }), { status: 403 });
    const body = await req.json();
    const { name, email, unit_id, role, birth_day, birth_month, birth_year, show_birthday } = body;
    if (!name || !email) return new Response(JSON.stringify({ error: "Nama dan email diperlukan." }), { status: 400 });
    const redirectTo = Deno.env.get("AVIA_INVITE_REDIRECT") || "avia://invite";
    const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
      redirectTo,
      data: { full_name: name, role: role || "staff", unit_id: unit_id || null }
    });
    if (error) throw error;
    if (data.user) {
      const { error: profileErr } = await admin.from("profiles").upsert({
        id: data.user.id, email, full_name: name, role: role || "staff",
        unit_id: unit_id || null, active: true,
        birth_day: birth_day || null, birth_month: birth_month || null, birth_year: birth_year || null,
        show_birthday: show_birthday !== false, invitation_status: "invited"
      });
      if (profileErr) throw profileErr;
    }
    return new Response(JSON.stringify({ ok: true, user_id: data.user?.id }), { headers: { "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), { status: 500, headers: { "Content-Type": "application/json" } });
  }
});
