import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
      },
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization") ?? "";

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) throw new Error("Unauthorized");

    const adminClient = createClient(supabaseUrl, serviceRole);

    const { data: profile, error: profileErr } = await adminClient
      .from("profiles")
      .select("role,active")
      .eq("id", user.id)
      .single();

    if (profileErr || !profile || profile.role !== "admin" || profile.active === false) {
      throw new Error("Admin sahaja boleh tambah staf");
    }

    const { name, email, unit_id, role = "staff", password, birth_day, birth_month, birth_year, show_birthday = true } = await req.json();
    if (!name || !email) throw new Error("Nama dan email diperlukan");

    const tempPassword = password || crypto.randomUUID().replaceAll("-", "").slice(0, 12) + "Aa1!";

    const { data: created, error: createErr } = await adminClient.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: { name },
    });
    if (createErr) throw createErr;

    const uid = created.user.id;

    const { error: insertErr } = await adminClient.from("profiles").insert({
      id: uid,
      full_name: name,
      email,
      unit_id: unit_id ?? null,
      role,
      active: true,
      must_change_password: true,
      birth_day: birth_day ?? null,
      birth_month: birth_month ?? null,
      birth_year: birth_year ?? null,
      show_birthday,
    });

    if (insertErr) {
      await adminClient.auth.admin.deleteUser(uid);
      throw insertErr;
    }

    await adminClient.from("audit_logs").insert({
      action: "ADD_STAFF",
      detail: `${name} • ${email}`,
      actor_id: user.id,
    }).catch(() => {});

    return new Response(JSON.stringify({
      ok: true,
      user_id: uid,
      temporary_password: tempPassword,
      login_id: email
    }), {
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      status: 200,
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      status: 400,
    });
  }
});
