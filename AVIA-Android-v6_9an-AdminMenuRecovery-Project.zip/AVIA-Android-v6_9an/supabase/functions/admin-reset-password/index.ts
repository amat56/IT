import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
  if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
  try{
    const url=Deno.env.get("SUPABASE_URL")!;
    const anon=Deno.env.get("SUPABASE_ANON_KEY")!;
    const service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const auth=req.headers.get("Authorization")??"";
    const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:{user},error:ue}=await userClient.auth.getUser();
    if(ue||!user) throw new Error("Unauthorized");
    const admin=createClient(url,service);
    const {data:me}=await admin.from("profiles").select("role,active").eq("id",user.id).single();
    if(!me||me.role!=="admin"||me.active===false) throw new Error("Admin sahaja boleh reset password");
    const {user_id}=await req.json();
    if(!user_id) throw new Error("user_id diperlukan");
    const {data:target,error:te}=await admin.from("profiles").select("email,full_name").eq("id",user_id).single();
    if(te||!target) throw new Error("Staf tidak ditemui");
    const temp="Avia@"+crypto.randomUUID().replaceAll("-","").slice(0,8)+"1";
    const {error:re}=await admin.auth.admin.updateUserById(user_id,{password:temp});
    if(re) throw re;
    await admin.from("profiles").update({must_change_password:true,updated_at:new Date().toISOString()}).eq("id",user_id);
    await admin.from("audit_logs").insert({action:"RESET_PASSWORD",detail:target.full_name||target.email,actor_id:user.id}).catch(()=>{});
    return new Response(JSON.stringify({ok:true,login_id:target.email,temporary_password:temp}),{status:200,headers:{...cors,"Content-Type":"application/json"}});
  }catch(e){
    return new Response(JSON.stringify({error:e.message}),{status:400,headers:{...cors,"Content-Type":"application/json"}});
  }
});
