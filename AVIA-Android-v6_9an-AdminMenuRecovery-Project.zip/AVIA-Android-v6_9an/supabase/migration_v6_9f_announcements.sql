-- AVIA v6.9f - Pemberitahuan Admin + Inbox Staf

create table if not exists public.announcements (
  id bigint generated always as identity primary key,
  title text not null,
  body text not null,
  target_type text not null default 'all' check (target_type in ('all','unit','user')),
  target_id text,
  created_by uuid references auth.users(id),
  created_by_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.announcement_reads (
  id bigint generated always as identity primary key,
  announcement_id bigint not null references public.announcements(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  read_at timestamptz not null default now(),
  unique(announcement_id,user_id)
);

alter table public.announcements enable row level security;
alter table public.announcement_reads enable row level security;

drop policy if exists announcements_read_authenticated on public.announcements;
create policy announcements_read_authenticated on public.announcements
for select to authenticated using (true);

drop policy if exists announcements_admin_insert on public.announcements;
create policy announcements_admin_insert on public.announcements
for insert to authenticated with check (
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);

drop policy if exists announcements_admin_delete on public.announcements;
create policy announcements_admin_delete on public.announcements
for delete to authenticated using (
  exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);

drop policy if exists announcement_reads_own_select on public.announcement_reads;
create policy announcement_reads_own_select on public.announcement_reads
for select to authenticated using (user_id=auth.uid());

drop policy if exists announcement_reads_own_insert on public.announcement_reads;
create policy announcement_reads_own_insert on public.announcement_reads
for insert to authenticated with check (user_id=auth.uid());
