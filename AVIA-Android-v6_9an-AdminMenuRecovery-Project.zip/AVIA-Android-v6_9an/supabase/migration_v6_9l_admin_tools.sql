-- AVIA v6.9l
alter table public.profiles add column if not exists archived boolean not null default false;
alter table public.announcements add column if not exists pinned boolean not null default false;
alter table public.announcements add column if not exists expires_at date;

create table if not exists public.app_settings (
  key text primary key,
  value text,
  updated_at timestamptz not null default now()
);

insert into public.app_settings(key,value)
values ('latest_version','6.9l')
on conflict (key) do update set value=excluded.value, updated_at=now();
