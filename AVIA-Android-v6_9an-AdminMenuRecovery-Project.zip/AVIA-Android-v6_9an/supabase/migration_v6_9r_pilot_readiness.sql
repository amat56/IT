-- AVIA v6.9r pilot-readiness additions

alter table public.profiles add column if not exists archived boolean not null default false;

create table if not exists public.user_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  favorite_user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,favorite_user_id)
);

alter table public.user_favorites enable row level security;
drop policy if exists favorites_owner_all on public.user_favorites;
create policy favorites_owner_all on public.user_favorites for all to authenticated
using (user_id=auth.uid()) with check (user_id=auth.uid());

create table if not exists public.app_settings (
  key text primary key, value text, updated_at timestamptz not null default now()
);
insert into public.app_settings(key,value) values ('latest_version','6.9r')
on conflict(key) do update set value=excluded.value,updated_at=now();
