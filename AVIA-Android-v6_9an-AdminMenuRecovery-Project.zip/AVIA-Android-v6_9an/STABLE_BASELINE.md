# AVIA v6.9ah - Stable Candidate Baseline

This version is intended for stabilization testing. Freeze new feature work while validating:
1. Demo Admin login
2. Demo Staff login
3. Add/Edit/Deactivate staff
4. Birthday editing/display
5. Calendar leave records
6. Admin menu/settings
7. Popup/Back/Menu behavior
8. Temporary password flow
9. Biometric enable/fallback
10. Backup/Restore configuration

When all checks pass, archive:
- Source ZIP
- Git commit/tag
- APK
- Supabase schema/migrations
- Configuration backup

Promote the tested build as the Production Baseline; do not overwrite it with future development.
