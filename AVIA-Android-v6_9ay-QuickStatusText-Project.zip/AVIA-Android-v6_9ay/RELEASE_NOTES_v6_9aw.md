# AVIA v6.9aw

- Header kanan kini menggunakan wordmark grafik AVIA yang diekstrak daripada muka depan aplikasi.
- Wordmark mengekalkan bentuk huruf AVIA dan anak panah biru asal.
- Tiada kotak ikon, Jata, subtitle atau latar ikon pada header.
- Quick Status kekal: Keluar Pejabat, Kursus, Cuti Rehat, Cuti Sakit.
