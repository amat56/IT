# AVIA v6.9ax

Pembetulan paparan:
- `Paparan Keseluruhan Bahagian` kini hanya berada dalam menu `Hari Ini`.
- Ia tidak lagi muncul dalam Update, Kalendar, Staf, Inbox, Laporan, Profil atau Admin.
- Fungsi filter unit masih dikekalkan untuk Hari Ini.
