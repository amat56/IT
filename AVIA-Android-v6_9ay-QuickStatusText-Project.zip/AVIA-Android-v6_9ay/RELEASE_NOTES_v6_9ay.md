# AVIA v6.9ay
Quick Status:
- Cuti -> Cuti Rehat
- MC -> Cuti Sakit
