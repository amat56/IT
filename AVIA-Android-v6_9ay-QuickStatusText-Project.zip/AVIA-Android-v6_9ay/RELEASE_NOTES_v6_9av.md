# AVIA v6.9av

Pembetulan header dan Quick Status:
- Penjuru kanan atas kini memaparkan wordmark `AVIA` sahaja.
- Ikon aplikasi penuh dibuang daripada header.
- Status `Demo / Belum Sync` kekal tidak dipaparkan di header.
- Quick Status:
  - Keluar Sekejap -> Keluar Pejabat
  - Mesyuarat Luar -> Kursus
  - Cuti -> Cuti Rehat
  - MC -> Cuti Sakit
