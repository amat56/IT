-- MyUnit Calendar v6.1
-- Edit/Delete status permissions:
--   1) Admin can UPDATE/DELETE any status.
--   2) Normal user can UPDATE/DELETE only their own status.
-- Requires public.profiles.id = auth.uid() and profiles.role.

alter table public.statuses
  add column if not exists updated_at timestamptz;

alter table public.statuses enable row level security;

drop policy if exists "statuses_update_own_or_admin" on public.statuses;
create policy "statuses_update_own_or_admin"
on public.statuses
for update
to authenticated
using (
  user_id = auth.uid()
  or exists (
    select 1 from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
      and coalesce(p.active,true) = true
  )
)
with check (
  user_id = auth.uid()
  or exists (
    select 1 from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
      and coalesce(p.active,true) = true
  )
);

drop policy if exists "statuses_delete_own_or_admin" on public.statuses;
create policy "statuses_delete_own_or_admin"
on public.statuses
for delete
to authenticated
using (
  user_id = auth.uid()
  or exists (
    select 1 from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
      and coalesce(p.active,true) = true
  )
);

-- Optional audit policies (adjust if base schema already defines stricter policies)
alter table public.audit_logs enable row level security;

drop policy if exists "audit_insert_authenticated" on public.audit_logs;
create policy "audit_insert_authenticated"
on public.audit_logs
for insert
to authenticated
with check (true);
