-- MyUnit Calendar v6.5
create unique index if not exists public_holidays_unique_date_name
on public.public_holidays(holiday_date, lower(name));

insert into public.public_holidays (holiday_date,name,scope,state_name)
values
('2026-01-01','Tahun Baharu 2026','state','WP Putrajaya'),
('2026-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2026-02-01','Hari Thaipusam','state','WP Putrajaya'),
('2026-02-17','Tahun Baharu Cina','federal',null),
('2026-02-18','Tahun Baharu Cina (Hari Kedua)','federal',null),
('2026-03-07','Hari Nuzul Al-Quran','state','WP Putrajaya'),
('2026-03-20','Hari Kelepasan Am Tambahan Sempena Hari Raya','federal',null),
('2026-03-21','Hari Raya Puasa','federal',null),
('2026-03-22','Hari Raya Puasa (Hari Kedua)','federal',null),
('2026-05-01','Hari Pekerja','federal',null),
('2026-05-27','Hari Raya Qurban','federal',null),
('2026-05-31','Hari Wesak','federal',null),
('2026-06-01','Hari Keputeraan Rasmi Yang di-Pertuan Agong','federal',null),
('2026-06-02','Cuti Gantian Hari Wesak','federal',null),
('2026-06-17','Awal Muharam (Maal Hijrah)','federal',null),
('2026-08-25','Maulidur Rasul','federal',null),
('2026-08-31','Hari Kebangsaan','federal',null),
('2026-09-16','Hari Malaysia','federal',null),
('2026-11-08','Hari Deepavali','federal',null),
('2026-12-25','Hari Krismas','federal',null)
on conflict do nothing;
