-- MyUnit Calendar v6.1d
-- New official status list.

-- If statuses.type is TEXT with CHECK constraint, recreate constraint.
-- Adjust constraint name below if your existing schema uses a different name.
alter table public.statuses
  drop constraint if exists statuses_type_check;

alter table public.statuses
  add constraint statuses_type_check
  check (type in (
    'outside_meeting',
    'inside_course',
    'office_work',
    'out_of_office',
    'annual_leave',
    'sick_leave',
    'public_holiday',
    'school_holiday',
    'quarantine',
    'unpaid_leave'
  ));

-- Optional mapping for legacy data.
update public.statuses set type='outside_meeting' where type in ('meeting','course','official');
update public.statuses set type='office_work' where type='office';
update public.statuses set type='out_of_office' where type='site';
update public.statuses set type='annual_leave' where type in ('leave','el');
update public.statuses set type='sick_leave' where type='mc';
update public.statuses set type='out_of_office' where type='wfh';
