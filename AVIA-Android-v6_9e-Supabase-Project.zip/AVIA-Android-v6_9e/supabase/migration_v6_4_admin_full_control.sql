-- MyUnit Calendar v6.4 - Admin Full Control

-- Allowed movement status list
alter table public.statuses drop constraint if exists statuses_type_check;
alter table public.statuses add constraint statuses_type_check check (type in ('outside_meeting','inside_course','out_of_office','annual_leave','sick_leave','public_holiday','quarantine','unpaid_leave'));

-- Admin can manage units
alter table public.units enable row level security;
drop policy if exists units_admin_insert on public.units;
create policy units_admin_insert on public.units for insert to authenticated with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));
drop policy if exists units_admin_update on public.units;
create policy units_admin_update on public.units for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true))) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));
drop policy if exists units_admin_delete on public.units;
create policy units_admin_delete on public.units for delete to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));

-- Admin can edit any profile; users can read profiles
alter table public.profiles enable row level security;
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true))) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));

-- Status update/delete: owner OR admin
drop policy if exists statuses_update_own_or_admin on public.statuses;
create policy statuses_update_own_or_admin on public.statuses for update to authenticated using (user_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true))) with check (user_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));
drop policy if exists statuses_delete_own_or_admin on public.statuses;
create policy statuses_delete_own_or_admin on public.statuses for delete to authenticated using (user_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and coalesce(p.active,true)));
