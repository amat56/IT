-- MyUnit Calendar v6.3 - Add Staff support

alter table public.profiles
  add column if not exists email text,
  add column if not exists full_name text,
  add column if not exists unit_name text,
  add column if not exists role text default 'staff',
  add column if not exists active boolean default true;

-- Recommended uniqueness
create unique index if not exists profiles_email_unique
  on public.profiles(lower(email))
  where email is not null;
