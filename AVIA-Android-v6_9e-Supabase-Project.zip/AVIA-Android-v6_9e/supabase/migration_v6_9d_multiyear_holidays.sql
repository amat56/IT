-- AVIA v6.9d - Multi-year fixed public holidays 2026-2030
-- Fixed-date Malaysia / WP Putrajaya holidays. Movable holidays remain admin-managed.

create unique index if not exists public_holidays_unique_date_name
on public.public_holidays(holiday_date, lower(name));

insert into public.public_holidays (holiday_date,name,scope,state_name)
values
('2026-01-01','Tahun Baru','state','WP Putrajaya'),
('2026-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2026-05-01','Hari Pekerja','federal',null),
('2026-08-31','Hari Merdeka','federal',null),
('2026-09-16','Hari Malaysia','federal',null),
('2026-12-25','Krismas','federal',null),
('2027-01-01','Tahun Baru','state','WP Putrajaya'),
('2027-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2027-05-01','Hari Pekerja','federal',null),
('2027-08-31','Hari Merdeka','federal',null),
('2027-09-16','Hari Malaysia','federal',null),
('2027-12-25','Krismas','federal',null),
('2028-01-01','Tahun Baru','state','WP Putrajaya'),
('2028-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2028-05-01','Hari Pekerja','federal',null),
('2028-08-31','Hari Merdeka','federal',null),
('2028-09-16','Hari Malaysia','federal',null),
('2028-12-25','Krismas','federal',null),
('2029-01-01','Tahun Baru','state','WP Putrajaya'),
('2029-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2029-05-01','Hari Pekerja','federal',null),
('2029-08-31','Hari Merdeka','federal',null),
('2029-09-16','Hari Malaysia','federal',null),
('2029-12-25','Krismas','federal',null),
('2030-01-01','Tahun Baru','state','WP Putrajaya'),
('2030-02-01','Hari Wilayah Persekutuan','state','WP Putrajaya'),
('2030-05-01','Hari Pekerja','federal',null),
('2030-08-31','Hari Merdeka','federal',null),
('2030-09-16','Hari Malaysia','federal',null),
('2030-12-25','Krismas','federal',null)
on conflict do nothing;
