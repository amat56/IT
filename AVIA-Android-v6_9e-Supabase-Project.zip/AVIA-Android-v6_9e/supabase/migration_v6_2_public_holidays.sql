-- MyUnit Calendar v6.2
-- Public holidays table + RLS

create table if not exists public.public_holidays (
  id uuid primary key default gen_random_uuid(),
  holiday_date date not null,
  name text not null,
  scope text not null default 'federal'
    check (scope in ('federal','state','internal')),
  state_name text null,
  created_by uuid null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_public_holidays_date
  on public.public_holidays(holiday_date);

alter table public.public_holidays enable row level security;

drop policy if exists "holidays_read_authenticated" on public.public_holidays;
create policy "holidays_read_authenticated"
on public.public_holidays
for select
to authenticated
using (true);

drop policy if exists "holidays_admin_insert" on public.public_holidays;
create policy "holidays_admin_insert"
on public.public_holidays
for insert
to authenticated
with check (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid()
      and p.role='admin'
      and coalesce(p.active,true)=true
  )
);

drop policy if exists "holidays_admin_update" on public.public_holidays;
create policy "holidays_admin_update"
on public.public_holidays
for update
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid()
      and p.role='admin'
      and coalesce(p.active,true)=true
  )
)
with check (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid()
      and p.role='admin'
      and coalesce(p.active,true)=true
  )
);

drop policy if exists "holidays_admin_delete" on public.public_holidays;
create policy "holidays_admin_delete"
on public.public_holidays
for delete
to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id=auth.uid()
      and p.role='admin'
      and coalesce(p.active,true)=true
  )
);

-- Sample only; delete/replace according to your actual holiday calendar.
-- insert into public.public_holidays(holiday_date,name,scope)
-- values ('2026-08-31','Hari Kebangsaan','federal');
