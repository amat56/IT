# AVIA v6.9bd

Dashboard Hari Ini ditambah:
- Jam + tarikh semasa.
- Pengumuman terkini dengan pautan terus ke Inbox.
- Waktu Solat sebagai kad optional yang boleh diaktifkan/diedit oleh Admin.
- Hari lahir staf dikekalkan dan hanya muncul apabila berkaitan.
- Cuti umum terdekat dipaparkan jika dalam 45 hari.

Nota Waktu Solat:
- Demo/current build menggunakan waktu yang ditetapkan Admin secara manual.
- Tiada waktu solat default diisi untuk mengelakkan paparan waktu yang tidak tepat.
- Integrasi sumber rasmi/API boleh dibuat dalam fasa production.
