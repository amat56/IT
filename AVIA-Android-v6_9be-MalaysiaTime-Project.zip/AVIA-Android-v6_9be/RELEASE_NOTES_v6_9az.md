# AVIA v6.9az
Menu Hari Ini:
- Label KPI `Cuti` ditukar kepada `Cuti Rehat`.
- Label `Cuti Sakit` dikekalkan (menggantikan istilah MC).
- Quick Status kekal `Cuti Rehat` dan `Cuti Sakit`.
