# AVIA v6.9bb

Inbox Admin:
- Admin kini nampak butang `+ Hantar Mesej` terus dalam menu Inbox.
- Butang ini membawa Admin ke ruangan Pemberitahuan untuk menghantar mesej.
- Staf biasa hanya melihat Inbox dan fungsi baca/tanda dibaca.
