# AVIA v6.9be

- Jam, tarikh dan logik hari lahir dipaksa menggunakan zon `Asia/Kuala_Lumpur` (MYT, UTC+8).
- Status hari lahir bertukar tepat mengikut tarikh Malaysia.
- Kad hari lahir diperiksa semula setiap 30 saat supaya pertukaran selepas 00:00 berlaku walaupun aplikasi masih terbuka.
