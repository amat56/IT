# AVIA v6.9bc

Bug fix menu Update:
- Dropdown staf di bahagian atas menu Update kini diisi semula setiap kali menu dibuka.
- Admin Demo melihat Staff 1-5 (akaun Admin tidak dimasukkan sebagai sasaran Update).
- Ketua Unit melihat staf dalam unitnya.
- Staf biasa hanya melihat dirinya sendiri.

Regression fix:
- Klik KPI Hari Ini (Di Pejabat / Luar Pejabat / Cuti Rehat / Cuti Sakit) kekal membuka senarai nama.
