# MyUnit Calendar Android v6.1 - Supabase Sync

## Perubahan v6
- Supabase cloud sync untuk semua telefon
- Supabase Auth email/password
- PostgreSQL database pusat melalui Supabase REST API
- auto sync setiap 20 saat + sync apabila app kembali aktif
- cache lokal untuk paparan terakhir jika talian terputus
- Admin: edit nama, unit, role, aktif/nyahaktif staf
- Admin: tambah unit dan lihat audit log
- tiada proses approval
- bottom navigation dibuang
- menu sementara menggunakan hamburger di bahagian atas

## Setup Supabase
Lihat `supabase/SETUP.md` dan jalankan `supabase/schema.sql`.

## Penting
Jangan masukkan `service_role` key ke dalam APK. Gunakan anon/publishable key sahaja.

## Build GitHub Actions jika ZIP v6 di-upload ke root repository
Gunakan workflow yang disertakan dalam `github-main-v6.yml`, atau salin kandungannya ke `.github/workflows/main.yml`.


## Tambahan v6.1
- Admin: edit/delete mana-mana rekod pergerakan.
- User: edit/delete rekod sendiri sahaja.
- Klik rekod pada kalendar untuk edit.
- Boleh betulkan tarikh/status/masa/lokasi/catatan.
- Audit log untuk update/delete.
- Supabase RLS enforce hak akses.


## Paparan profil
- Bahagian: UNIT IT
- Tujuan: Maklumat Pergerakan Pegawai


## Perubahan v6.1c
Pilihan status dibuang: WFH, Lawatan Tapak, Pejabat.
Status aktif: Cuti, MC, EL, Mesyuarat Luar, Kursus, Tugas Rasmi Luar.


## Perubahan v6.1d
Senarai status digantikan dengan 10 status rasmi baharu. Item `NOTA` dibuang.


## Tambahan v6.2
- Cuti Umum dipaparkan kuning dalam kalendar.
- Admin boleh tambah/edit/padam Cuti Umum.
- Cuti Umum disimpan dalam Supabase `public_holidays`.
- Sedia untuk auto-import cuti umum Malaysia kemudian.


## Perubahan v6.2b
Header atas `MyUnit Calendar` dibuang untuk paparan lebih bersih.


## v6.3
- Butang `+ Tambah Staf` dipulangkan dalam Admin > Staf.
- Demo mode: tambah staf terus seperti versi awal.
- Supabase mode: cipta login staf secara selamat melalui Edge Function.


## v6.4 Admin Full Control
- Header title dikosongkan.
- Status `Bekerja di Pejabat/Mesyuarat di Pejabat` dan `Cuti Sekolah` dibuang.
- Admin: tambah/edit/nyahaktif/padam staf.
- Admin: tambah/edit/padam unit.
- Admin: tambah/edit/padam semua rekod kalendar/pergerakan.
- User biasa: edit/padam rekod sendiri sahaja.
- Admin: tambah/edit/padam Cuti Umum.
- Audit log kekal tidak boleh diedit untuk integriti.
