# AVIA Android v6.9 - Supabase Sync

## Perubahan v6
- Supabase cloud sync untuk semua telefon
- Supabase Auth email/password
- PostgreSQL database pusat melalui Supabase REST API
- auto sync setiap 20 saat + sync apabila app kembali aktif
- cache lokal untuk paparan terakhir jika talian terputus
- Admin: edit nama, unit, role, aktif/nyahaktif staf
- Admin: tambah unit dan lihat audit log
- tiada proses approval
- bottom navigation dibuang
- menu sementara menggunakan hamburger di bahagian atas

## Setup Supabase
Lihat `supabase/SETUP.md` dan jalankan `supabase/schema.sql`.

## Penting
Jangan masukkan `service_role` key ke dalam APK. Gunakan anon/publishable key sahaja.

## Build GitHub Actions jika ZIP v6 di-upload ke root repository
Gunakan workflow yang disertakan dalam `github-main-v6.yml`, atau salin kandungannya ke `.github/workflows/main.yml`.


## Tambahan v6.1
- Admin: edit/delete mana-mana rekod pergerakan.
- User: edit/delete rekod sendiri sahaja.
- Klik rekod pada kalendar untuk edit.
- Boleh betulkan tarikh/status/masa/lokasi/catatan.
- Audit log untuk update/delete.
- Supabase RLS enforce hak akses.


## Paparan profil
- Bahagian: UNIT IT
- Tujuan: Maklumat Pergerakan Pegawai


## Perubahan v6.1c
Pilihan status dibuang: WFH, Lawatan Tapak, Pejabat.
Status aktif: Cuti, MC, EL, Mesyuarat Luar, Kursus, Tugas Rasmi Luar.


## Perubahan v6.1d
Senarai status digantikan dengan 10 status rasmi baharu. Item `NOTA` dibuang.


## Tambahan v6.2
- Cuti Umum dipaparkan kuning dalam kalendar.
- Admin boleh tambah/edit/padam Cuti Umum.
- Cuti Umum disimpan dalam Supabase `public_holidays`.
- Sedia untuk auto-import cuti umum Malaysia kemudian.


## Perubahan v6.2b
Header atas `MyUnit Calendar` dibuang untuk paparan lebih bersih.


## v6.3
- Butang `+ Tambah Staf` dipulangkan dalam Admin > Staf.
- Demo mode: tambah staf terus seperti versi awal.
- Supabase mode: cipta login staf secara selamat melalui Edge Function.


## v6.4 Admin Full Control
- Header title dikosongkan.
- Status `Bekerja di Pejabat/Mesyuarat di Pejabat` dan `Cuti Sekolah` dibuang.
- Admin: tambah/edit/nyahaktif/padam staf.
- Admin: tambah/edit/padam unit.
- Admin: tambah/edit/padam semua rekod kalendar/pergerakan.
- User biasa: edit/padam rekod sendiri sahaja.
- Admin: tambah/edit/padam Cuti Umum.
- Audit log kekal tidak boleh diedit untuk integriti.


## v6.4c
- Fix Edit Staf dalam Demo/Offline mode.
- Fix Aktif/Nyahaktif staf dalam Demo mode.
- Demo mode kini boleh simpan rekod pergerakan lokal.


## v6.5
- Tarikh cuti umum WP Putrajaya 2026 dimasukkan automatik.
- Seluruh kotak tarikh cuti umum berwarna kuning.
- Label nama cuti dipaparkan dalam kotak.
- Admin masih boleh tambah/edit/padam cuti khas sendiri.


## v6.6
- Cuti umum penting Malaysia/WP Putrajaya 2026 dipaparkan dalam kotak kalendar.
- Nama cuti seperti Tahun Baru, Tahun Baru Cina, Hari Raya Aidilfitri, Hari Raya Aidiladha, Hari Pekerja, Hari Wesak, Hari Merdeka, Hari Malaysia, Deepavali dan Krismas dipaparkan.
- Warna kotak cuti ditukar kepada kuning cair/pastel.


## v6.6b
- Fix butang Tambah Staf dalam Demo mode.
- Password tidak diperlukan untuk Demo mode.
- Password minimum 8 aksara hanya untuk Supabase mode.
- Password Supabase boleh dikosongkan untuk jana automatik.


## v6.6c
- Fix cuti umum hilang dalam Demo mode.
- Tarikh bulan sebelum/selepas dipaparkan dalam grid kalendar.
- 31 Ogos akan muncul pada permulaan kalendar September dan ditanda `Hari Merdeka`.
- Kotak cuti umum kekal kuning cair.


## v6.7 - Stabilized Admin + Calendar
- Cuti umum penting 2026 auto muncul dalam kalendar.
- Kotak cuti umum berwarna kuning cair dan memaparkan nama cuti.
- 31 Ogos dipaparkan sebagai Hari Merdeka; 16 September sebagai Hari Malaysia.
- Grid kalendar memaparkan tarikh bulan bersebelahan.
- Admin boleh tambah/edit/padam staf.
- Admin boleh tambah/edit/padam Bahagian/Unit.
- Admin boleh edit/padam semua rekod pergerakan.
- Admin boleh tambah/edit/padam Cuti Umum.
- Demo mode tidak memerlukan password untuk Tambah Staf.


## v6.7b
- Fix butang Tambah Staf dalam popup.
- Demo mode simpan staf baharu dalam localStorage.
- Butang Batal juga diperbaiki.


## v6.7c
- Tarikh Tamat auto +1 hari selepas Tarikh Mula.
- Contoh: 19 Sept -> auto 20 Sept.
- Pengguna masih boleh ubah Tarikh Tamat secara manual untuk tempoh lebih panjang.
- Tarikh Tamat tidak dibenarkan lebih awal daripada Tarikh Mula.


## v6.8
- Medan Masa Mula/Masa Tamat dibuang.
- Dashboard Hari Ini: carian + filter unit + peringatan in-app.
- Laporan bulanan + filter + Export CSV.
- Role Ketua Unit boleh urus staf/pergerakan dalam unit sendiri.
- Bulk update ramai staf.
- Audit edit pergerakan simpan sebelum/selepas.
- Backup/restore JSON untuk Demo mode.
- Cuti umum kekal auto dalam kalendar dan boleh diurus Admin.


## v6.8a
- 4 kotak KPI Hari Ini kini boleh diklik.
- Klik Di Pejabat, Cuti, Cuti Sakit atau Luar Pejabat untuk melihat senarai nama staf dalam kategori tersebut.
- Jumlah dalam popup sentiasa sepadan dengan nombor KPI.
- Carian nama dan filter Bahagian/Unit turut digunakan dalam popup.

## v6.8b
- Dashboard atas ditukar daripada 4 kotak kepada satu kad `Status Hari Ini`.
- Paparan: Di Pejabat, Luar Pejabat, Cuti dan Cuti Sakit.
- Semua staf aktif dianggap `Di Pejabat` secara default jika tiada rekod pergerakan pada hari tersebut.
- Bila staf isi cuti / sakit / luar pejabat, staf automatik dikeluarkan daripada jumlah `Di Pejabat` dan dimasukkan ke kategori berkaitan.
- Klik mana-mana baris/jumlah untuk melihat nama, unit dan status staf.
- Reminder / popup kemas kini pergerakan dibuang.


## v6.9 - AVIA Branding
- Nama aplikasi ditukar kepada **AVIA**.
- Nama penuh: **Availability & Visibility Information Application**.
- Header baharu menggunakan identiti biru digital AVIA.
- Nama fail eksport laporan dan backup ditukar kepada AVIA.
- Workflow GitHub Actions dikemas kini untuk projek AVIA v6.9.
- Nota: Jata Negara belum dibundel sebagai launcher icon dalam source kerana fail grafik rasmi/approved perlu dibekalkan terlebih dahulu.

## AVIA v6.9a — Launcher Branding
- Nama aplikasi kekal **AVIA**.
- Launcher icon Android kini menggunakan reka bentuk AVIA berwarna biru dengan tulisan **AVIA** pada ikon.
- `AndroidManifest.xml` menggunakan `@mipmap/ic_launcher` dan `@mipmap/ic_launcher_round`.
- Ikon disediakan untuk mdpi, hdpi, xhdpi, xxhdpi dan xxxhdpi.
- Nama penuh dalam header: **Availability & Visibility Information Application**.
