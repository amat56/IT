# AVIA v6.9bi Recovery v3

This package uses the complete `index.html` supplied by the user on 21 September 2026 as the web-app baseline.

## Confirmed native baseline
- Package / namespace: `my.gov.demo.myunit`
- WebView entry: `file:///android_asset/index.html`
- Native bridges: `AndroidBiometric`, `AndroidLocation`
- Deep links: `avia://invite`, `avia://reset-password`
- Permissions: INTERNET, coarse/fine location, USE_BIOMETRIC
- Java: 17
- Gradle workflow: 8.9
- Android compile/target SDK: 35
- Version name: `6.9bi`

## Recovery v3 changes
- Replaced the reconstructed HTML with the complete uploaded `index.html`.
- Standardised user-visible/current build version markers to `v6.9bi`.
- Fixed KPI inline handlers from the undefined `openKpiDetail(...)` to `openKpiDetails(...)`.
- Added hidden compatibility containers `present` and `away` because legacy render wrappers still reference them.
- Replaced an undefined `showView?.('admin')` call with the existing `show('admin')` navigation function.
- Added a `globalError` surface used by sync/error handling.
- Added an AVIA text fallback when `avia_wordmark.png` is not present in the package.
- Preserved historical localStorage key suffixes to avoid breaking existing device data/configuration.

## Static audit
- JavaScript syntax validated with `node --check`.
- No duplicate literal HTML IDs were intentionally introduced by Recovery v3.
- Several historical function definitions occur more than once (`renderAll`, `renderToday`, `renderAdmin`, `saveStatus`, etc.). These are part of the accumulated patch/wrapper architecture in the recovered source. Recovery v3 does not aggressively delete them because later definitions/wrappers intentionally override earlier behavior. Refactoring them should be a separate tested release.
- Some legacy element references are optional/guarded and no longer have corresponding UI elements (`todaySearch`, `favoriteStaffList`, `adminTrendCard`, etc.). They have been left in place where they do not create an unguarded runtime failure.

## Build validation limitation
The current execution environment does not have the Gradle CLI/Android SDK toolchain installed, so an APK was not compiled locally. The included GitHub Actions workflow is configured to build the debug APK with Java 17 and Gradle 8.9.

## Recovery v4 UI alignment
- UNIT IT/organization label centered directly below Jata Negara.
- AVIA subtitle constrained to the wordmark width and centered directly below the AVIA graphic.


## Recovery v6 header alignment
- Added a definitive CSS override after all existing header CSS.
- UNIT IT is fixed to the exact width of the Jata container and centered directly underneath it.
- AVIA subtitle is fixed to the exact width of the AVIA wordmark and centered directly underneath it.
- Uses explicit grid columns and !important overrides to prevent older accumulated CSS from retaining the previous positions.

## Recovery v7 header correction
Header markup was rebuilt, not only restyled. UNIT IT is now a direct child of the same Jata brand block, and the subtitle is a direct child of the AVIA brand block. New IDs `jataBrandBlock` and `aviaBrandBlock` are used with a hard-reset CSS layer to prevent legacy header rules from controlling alignment.

## v8 header correction
- Jata Negara block moved further left, immediately after hamburger menu.
- UNIT IT is centered directly under the Jata Negara using the same fixed width as the Jata block.
- AVIA wordmark/subtitle block remains centered in the remaining header area.
- Android launcher icon resources were NOT changed in this revision.
- The recovered project still references `assets/avia_wordmark.png`; the original image asset is not present in the recovered ZIP, so exact original wordmark rendering requires that asset to be supplied.

## v9 header alignment
- Jata Negara retained on the left side of the blue header.
- UNIT IT is centered directly below the Jata block.
- AVIA wordmark remains on the right side of the blue header.
- Subtitle is centered directly below the AVIA wordmark.
- No launcher icon change was made.

## R11 force-refresh build
- Inline AVIA SVG retained; no dependency on avia_wordmark.png.
- WebView cache disabled with LOAD_NO_CACHE and clearCache(true) on startup.
- versionCode incremented to 60911 so Android treats this as a newer build.
- HTML marker: AVIA_RECOVERY_V11_INLINE_SVG_HEADER_NOCACHE.
- About screen shows Build R11 for verification.


## Recovery v12
- Launcher icon Android now uses the same AVIA graphic language as the dashboard header.
- Added drawable-nodpi/avia_launcher.png generated from the AVIA dashboard SVG artwork.
- Manifest icon and roundIcon now point to @drawable/avia_launcher.
- versionCode bumped to 60912; About shows Build R12.


R13: Grafik AVIA dashboard direka semula dengan gaya digital/circuit, glow, data nodes dan angular wordmark. Launcher icon diselaraskan. versionCode 60913.

- R16: Dashboard AVIA graphic now uses the exact same PNG asset as the Android launcher icon (avia_launcher.png copied to assets/avia_dashboard_logo.png).

- R17: Dashboard AVIA graphic now points directly to the same `avia_launcher.png` asset used by the Android app icon, ensuring both are visually identical.

- R18: Polished dashboard AVIA graphic presentation by matching the blue header tone, adding a rounded glass-style brand panel, and softening the icon appearance so it blends better with the header.
