# AVIA v6.9bi v13 - Production Readiness Check

## Status
Production Candidate PC1 - suitable for controlled UAT/pilot, not yet approved as final production release.

## Hardened in this candidate
- Android backup disabled (`allowBackup=false`, `fullBackupContent=false`).
- App debugging disabled in the manifest.
- WebView remote debugging disabled.
- Mixed HTTP content blocked.
- Safe Browsing enabled on supported Android versions.
- WebView geolocation disabled because AVIA uses its own Android location bridge.
- Demo Offline and Demo Staff entry points hidden/disabled.
- Final JavaScript guard prevents accidental demo launch.
- Logout clears cached staff/status data and pending offline operations.
- Android version metadata aligned to v13 (`versionCode 60913`, `versionName 6.9bi-v13`).

## Must be verified before live rollout
1. Supabase Row Level Security (RLS): confirm staff cannot read/write another staff member's protected data except where intentionally allowed.
2. Edge Functions: verify `admin-invite-user`, password reset, and user deletion are deployed and authorization-checked server-side.
3. Release signing: current GitHub workflow builds a debug APK. A live release must be signed with the organisation's release keystore and protected GitHub secrets.
4. UAT: test admin invite -> email -> set password -> login -> status update -> admin visibility -> logout -> relogin on real devices.
5. Deep links: test `avia://invite` and `avia://reset-password` on target Android devices.
6. Biometric: test on representative Samsung/Xiaomi/other Android devices.
7. Data retention/privacy: confirm which staff profile/status/audit fields may be cached on devices and for how long.

## Residual technical risks
- Tokens are still held in WebView localStorage. For higher assurance, migrate access/refresh token storage to Android Keystore-backed storage.
- `setAllowUniversalAccessFromFileURLs(true)` remains enabled because the current app loads `file:///android_asset/index.html` and performs HTTPS API calls. A future hardening release should migrate to `WebViewAssetLoader` / an HTTPS appassets origin and disable universal file access.
- Prayer-time functionality depends on external web services; availability and organisational acceptance should be confirmed.
