# AVIA v6.9bi Recovery v3

AVIA — Availability & Visibility Information Application.

This is the recovered Android WebView project using the complete `index.html` supplied for the AVIA v6.9bi line.

## Main source locations
- `app/src/main/assets/index.html` — AVIA web application
- `app/src/main/java/my/gov/demo/myunit/MainActivity.java` — Android WebView, biometric, location and deep-link bridge
- `app/src/main/AndroidManifest.xml` — permissions and deep links
- `.github/workflows/main.yml` — GitHub Actions APK build

## Key functions present in the recovered web app
- Dashboard status: Di Pejabat, Luar Pejabat, Cuti Rehat, Cuti Sakit
- Calendar and Malaysia/WP Putrajaya public holidays
- Staff / Admin / Ketua Unit role flows
- Inbox and announcements
- Birthday display
- Reports and CSV export
- Bulk status update
- Backup / restore configuration
- Supabase Auth / REST integration hooks
- Invitation and password-recovery deep links
- Biometric login / session unlock
- GPS location bridge and JAKIM prayer-zone flow
- Prayer-time active highlight
- Offline/demo support

## GitHub Actions build
Upload the **contents of this project folder** to the root of a GitHub repository, then run:

**Actions → Build Android APK AVIA v6.9bi → Run workflow**

Expected artifact name:

`AVIA-v6_9bi-APK`

Expected APK path inside the build:

`app/build/outputs/apk/debug/app-debug.apk`

See `RECOVERY_NOTES.md` for the v3 audit and recovery changes.


## AVIA v6.9bi v13 - Production Candidate PC1
This package applies non-breaking hardening for UAT/production-readiness: Android backup disabled, WebView debugging disabled, mixed HTTP content blocked, Safe Browsing enabled on supported Android versions, demo entry points hidden/disabled, logout clears cached organisation data, and Android version metadata aligned to v13.

This is still a production candidate, not a final signed production release. Supabase RLS, Edge Functions, end-to-end UAT, and release signing must be verified before organisation-wide rollout.
