# AVIA v6.9ar - Stabilization Test Checklist

Tujuan versi ini ialah menguji kestabilan. Tiada fungsi baharu utama ditambah.

## A. Startup / Demo
- [ ] Install APK baharu
- [ ] Buka AVIA
- [ ] Jika Supabase belum dikonfigurasi, hanya skrin Supabase Setup dipaparkan
- [ ] Tekan Demo Offline
- [ ] Terus masuk sebagai Admin Demo
- [ ] Header/menu boleh ditekan
- [ ] Menu Admin dipaparkan

## B. Dashboard
- [ ] Dashboard ringkas dipaparkan tanpa:
  - Siapa Tiada Hari Ini
  - Ada di Pejabat
  - Tiada di Pejabat
  - Emergency View
  - Cari Nama Staf
  - Staf Kegemaran
  - Trend 30 Hari
- [ ] Status Hari Ini dipaparkan dengan betul
- [ ] Hari Lahir muncul jika berkaitan
- [ ] 7 Hari Akan Datang berfungsi jika masih diaktifkan

## C. Menu Update
- [ ] Jenis status/pergerakan boleh dipilih
- [ ] Cuti Umum TIADA dalam pilihan staf
- [ ] Masa Mula TIADA
- [ ] Masa Tamat TIADA
- [ ] Lokasi TIADA
- [ ] Tarikh Mula ada
- [ ] Tarikh Tamat ada
- [ ] Catatan ringkas ada
- [ ] Simpan rekod berjaya
- [ ] Rekod muncul di dashboard/kalendar

## D. Kalendar
- [ ] Cuti umum dipaparkan secara automatik
- [ ] Rekod cuti demo September dipaparkan
- [ ] Staff 1: 11-15 Sept
- [ ] Staff 2: 1, 23, 28-29 Sept
- [ ] Staff 4: 7, 9, 18 Sept
- [ ] Staff 5: 23 Sept
- [ ] Sabtu/Ahad dipaparkan seperti reka bentuk semasa

## E. Admin
- [ ] Menu Admin muncul
- [ ] Staff 1-5 dipaparkan
- [ ] Semua Staff 1-5 berada dalam UNIT IT
- [ ] Tambah staf berfungsi
- [ ] Edit staf berfungsi
- [ ] Nyahaktif/Aktifkan staf berfungsi
- [ ] Delete berfungsi jika dibenarkan
- [ ] Tarikh lahir boleh ditambah/edit
- [ ] Unit boleh diurus
- [ ] Status/Pergerakan boleh dikonfigurasi
- [ ] Cuti Umum boleh diurus oleh Admin
- [ ] Backup/Restore konfigurasi berfungsi
- [ ] Identiti aplikasi boleh dikemas kini mengikut setting yang disediakan

## F. Login / Akaun
- [ ] Login email + password berfungsi apabila Supabase disambung
- [ ] Lupa Password memaparkan flow reset
- [ ] Admin invite staf menggunakan email rasmi
- [ ] Demo invitation tidak menghantar email sebenar
- [ ] Biometrik optional selepas login
- [ ] Session lock berfungsi
- [ ] Login gagal berulang mengikuti kawalan semasa
- [ ] Last Login dipaparkan jika data tersedia

## G. Popup / Navigation Android
- [ ] Butang Batal menutup popup
- [ ] Tekan luar popup menutup popup jika berkaitan
- [ ] Butang Back menutup popup dahulu
- [ ] Hamburger menu boleh dibuka
- [ ] Drawer boleh ditutup
- [ ] App tidak terus minimize bila popup masih terbuka

## H. Backup / Recovery
- [ ] Backup konfigurasi boleh dibuat
- [ ] Restore konfigurasi boleh dibuat
- [ ] ZIP source versi ini disimpan
- [ ] Git commit/tag disimpan
- [ ] APK stabil disimpan selepas lulus ujian

## Keputusan
- Tarikh ujian:
- Penguji:
- Telefon:
- Android:
- Keputusan: PASS / FAIL
- Catatan bug:
