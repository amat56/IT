# AVIA v6.9at
Kemasan Quick Status:
- Keluar Sekejap -> Keluar Pejabat
- Mesyuarat Luar -> Kursus
- Cuti -> Cuti Rehat
- MC -> Cuti Sakit
