# AVIA v6.9ar - Stabilization QA

Versi ini adalah kesinambungan v6.9aq untuk tujuan stabilization/testing.

Perubahan utama:
- Tiada fungsi besar baharu.
- Versi aplikasi ditandakan v6.9ar.
- Checklist ujian formal ditambah.
- Workflow GitHub Actions diselaraskan kepada ZIP versi semasa.
- Fokus selepas ini: baiki bug sahaja sehingga calon production stabil.
