# AVIA v6.9au
- Gantikan paparan Demo/Offline dan Belum Sync di kanan atas header dengan logo AVIA.
- Status sync masih dikekalkan secara dalaman dan pada paparan berkaitan untuk diagnostik.
