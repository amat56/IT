# AVIA v6.9as
- Buang 7 Hari Akan Datang daripada Hari Ini.
- Buang Meeting / Tugas Luar daripada Hari Ini.
- Buang Pergerakan Esok daripada Hari Ini.
- Kalendar dan data pergerakan tidak dipadam.
- Target DOM tersembunyi dikekalkan untuk keserasian renderer lama.
