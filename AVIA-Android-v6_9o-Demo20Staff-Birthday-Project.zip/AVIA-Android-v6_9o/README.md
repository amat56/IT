# AVIA Android v6.9 - Supabase Sync

## Perubahan v6
- Supabase cloud sync untuk semua telefon
- Supabase Auth email/password
- PostgreSQL database pusat melalui Supabase REST API
- auto sync setiap 20 saat + sync apabila app kembali aktif
- cache lokal untuk paparan terakhir jika talian terputus
- Admin: edit nama, unit, role, aktif/nyahaktif staf
- Admin: tambah unit dan lihat audit log
- tiada proses approval
- bottom navigation dibuang
- menu sementara menggunakan hamburger di bahagian atas

## Setup Supabase
Lihat `supabase/SETUP.md` dan jalankan `supabase/schema.sql`.

## Penting
Jangan masukkan `service_role` key ke dalam APK. Gunakan anon/publishable key sahaja.

## Build GitHub Actions jika ZIP v6 di-upload ke root repository
Gunakan workflow yang disertakan dalam `github-main-v6.yml`, atau salin kandungannya ke `.github/workflows/main.yml`.


## Tambahan v6.1
- Admin: edit/delete mana-mana rekod pergerakan.
- User: edit/delete rekod sendiri sahaja.
- Klik rekod pada kalendar untuk edit.
- Boleh betulkan tarikh/status/masa/lokasi/catatan.
- Audit log untuk update/delete.
- Supabase RLS enforce hak akses.


## Paparan profil
- Bahagian: UNIT IT
- Tujuan: Maklumat Pergerakan Pegawai


## Perubahan v6.1c
Pilihan status dibuang: WFH, Lawatan Tapak, Pejabat.
Status aktif: Cuti, MC, EL, Mesyuarat Luar, Kursus, Tugas Rasmi Luar.


## Perubahan v6.1d
Senarai status digantikan dengan 10 status rasmi baharu. Item `NOTA` dibuang.


## Tambahan v6.2
- Cuti Umum dipaparkan kuning dalam kalendar.
- Admin boleh tambah/edit/padam Cuti Umum.
- Cuti Umum disimpan dalam Supabase `public_holidays`.
- Sedia untuk auto-import cuti umum Malaysia kemudian.


## Perubahan v6.2b
Header atas `MyUnit Calendar` dibuang untuk paparan lebih bersih.


## v6.3
- Butang `+ Tambah Staf` dipulangkan dalam Admin > Staf.
- Demo mode: tambah staf terus seperti versi awal.
- Supabase mode: cipta login staf secara selamat melalui Edge Function.


## v6.4 Admin Full Control
- Header title dikosongkan.
- Status `Bekerja di Pejabat/Mesyuarat di Pejabat` dan `Cuti Sekolah` dibuang.
- Admin: tambah/edit/nyahaktif/padam staf.
- Admin: tambah/edit/padam unit.
- Admin: tambah/edit/padam semua rekod kalendar/pergerakan.
- User biasa: edit/padam rekod sendiri sahaja.
- Admin: tambah/edit/padam Cuti Umum.
- Audit log kekal tidak boleh diedit untuk integriti.


## v6.4c
- Fix Edit Staf dalam Demo/Offline mode.
- Fix Aktif/Nyahaktif staf dalam Demo mode.
- Demo mode kini boleh simpan rekod pergerakan lokal.


## v6.5
- Tarikh cuti umum WP Putrajaya 2026 dimasukkan automatik.
- Seluruh kotak tarikh cuti umum berwarna kuning.
- Label nama cuti dipaparkan dalam kotak.
- Admin masih boleh tambah/edit/padam cuti khas sendiri.


## v6.6
- Cuti umum penting Malaysia/WP Putrajaya 2026 dipaparkan dalam kotak kalendar.
- Nama cuti seperti Tahun Baru, Tahun Baru Cina, Hari Raya Aidilfitri, Hari Raya Aidiladha, Hari Pekerja, Hari Wesak, Hari Merdeka, Hari Malaysia, Deepavali dan Krismas dipaparkan.
- Warna kotak cuti ditukar kepada kuning cair/pastel.


## v6.6b
- Fix butang Tambah Staf dalam Demo mode.
- Password tidak diperlukan untuk Demo mode.
- Password minimum 8 aksara hanya untuk Supabase mode.
- Password Supabase boleh dikosongkan untuk jana automatik.


## v6.6c
- Fix cuti umum hilang dalam Demo mode.
- Tarikh bulan sebelum/selepas dipaparkan dalam grid kalendar.
- 31 Ogos akan muncul pada permulaan kalendar September dan ditanda `Hari Merdeka`.
- Kotak cuti umum kekal kuning cair.


## v6.7 - Stabilized Admin + Calendar
- Cuti umum penting 2026 auto muncul dalam kalendar.
- Kotak cuti umum berwarna kuning cair dan memaparkan nama cuti.
- 31 Ogos dipaparkan sebagai Hari Merdeka; 16 September sebagai Hari Malaysia.
- Grid kalendar memaparkan tarikh bulan bersebelahan.
- Admin boleh tambah/edit/padam staf.
- Admin boleh tambah/edit/padam Bahagian/Unit.
- Admin boleh edit/padam semua rekod pergerakan.
- Admin boleh tambah/edit/padam Cuti Umum.
- Demo mode tidak memerlukan password untuk Tambah Staf.


## v6.7b
- Fix butang Tambah Staf dalam popup.
- Demo mode simpan staf baharu dalam localStorage.
- Butang Batal juga diperbaiki.


## v6.7c
- Tarikh Tamat auto +1 hari selepas Tarikh Mula.
- Contoh: 19 Sept -> auto 20 Sept.
- Pengguna masih boleh ubah Tarikh Tamat secara manual untuk tempoh lebih panjang.
- Tarikh Tamat tidak dibenarkan lebih awal daripada Tarikh Mula.


## v6.8
- Medan Masa Mula/Masa Tamat dibuang.
- Dashboard Hari Ini: carian + filter unit + peringatan in-app.
- Laporan bulanan + filter + Export CSV.
- Role Ketua Unit boleh urus staf/pergerakan dalam unit sendiri.
- Bulk update ramai staf.
- Audit edit pergerakan simpan sebelum/selepas.
- Backup/restore JSON untuk Demo mode.
- Cuti umum kekal auto dalam kalendar dan boleh diurus Admin.


## v6.8a
- 4 kotak KPI Hari Ini kini boleh diklik.
- Klik Di Pejabat, Cuti, Cuti Sakit atau Luar Pejabat untuk melihat senarai nama staf dalam kategori tersebut.
- Jumlah dalam popup sentiasa sepadan dengan nombor KPI.
- Carian nama dan filter Bahagian/Unit turut digunakan dalam popup.

## v6.8b
- Dashboard atas ditukar daripada 4 kotak kepada satu kad `Status Hari Ini`.
- Paparan: Di Pejabat, Luar Pejabat, Cuti dan Cuti Sakit.
- Semua staf aktif dianggap `Di Pejabat` secara default jika tiada rekod pergerakan pada hari tersebut.
- Bila staf isi cuti / sakit / luar pejabat, staf automatik dikeluarkan daripada jumlah `Di Pejabat` dan dimasukkan ke kategori berkaitan.
- Klik mana-mana baris/jumlah untuk melihat nama, unit dan status staf.
- Reminder / popup kemas kini pergerakan dibuang.


## v6.9 - AVIA Branding
- Nama aplikasi ditukar kepada **AVIA**.
- Nama penuh: **Availability & Visibility Information Application**.
- Header baharu menggunakan identiti biru digital AVIA.
- Nama fail eksport laporan dan backup ditukar kepada AVIA.
- Workflow GitHub Actions dikemas kini untuk projek AVIA v6.9.
- Nota: Jata Negara belum dibundel sebagai launcher icon dalam source kerana fail grafik rasmi/approved perlu dibekalkan terlebih dahulu.

## AVIA v6.9a — Launcher Branding
- Nama aplikasi kekal **AVIA**.
- Launcher icon Android kini menggunakan reka bentuk AVIA berwarna biru dengan tulisan **AVIA** pada ikon.
- `AndroidManifest.xml` menggunakan `@mipmap/ic_launcher` dan `@mipmap/ic_launcher_round`.
- Ikon disediakan untuk mdpi, hdpi, xhdpi, xxhdpi dan xxxhdpi.
- Nama penuh dalam header: **Availability & Visibility Information Application**.


## AVIA v6.9b
- Ruangan Email dibuang daripada borang Tambah Staf.
- AVIA menjana ID akaun dalaman secara automatik untuk keperluan teknikal Supabase Auth.
- Email dalaman `@avia.local` tidak dipaparkan dalam senarai pengurusan staf.


## AVIA v6.9c
- Tambah penapis skop global: Keseluruhan Bahagian atau Unit tertentu.
- Pemilihan Unit digunakan serentak pada Dashboard Status Hari Ini dan Kalendar.
- Pilih contoh UNIT IT: jumlah dashboard dan nama pergerakan dalam kalendar hanya untuk UNIT IT.
- Pilih Keseluruhan Bahagian: semua staf/rekod dipaparkan.
- Pilihan Unit disimpan pada peranti supaya kekal semasa buka semula aplikasi.


## v6.9e
- Sabtu, Ahad dan Cuti Umum memaparkan simbol `—` pada ringkasan Status Hari Ini.
- Staf tidak lagi dianggap berada di pejabat pada hari bukan bekerja.
- Nama Hujung Minggu / Cuti Umum dipaparkan pada dashboard.
- Struktur Cuti Umum menyokong multi-year.
- Tarikh tetap utama Malaysia / WP Putrajaya tersedia automatik untuk 2026–2030.
- Cuti berubah tarikh seperti Aidilfitri, Aidiladha, Tahun Baru Cina, Deepavali dan lain-lain boleh ditambah/edit oleh Admin bagi tahun seterusnya tanpa ubah coding.


## v6.9f - Pemberitahuan & Inbox
- Admin boleh hantar pemberitahuan kepada semua staf, unit tertentu atau staf tertentu.
- Staf mempunyai Inbox baca sahaja.
- Badge merah menunjukkan bilangan mesej belum dibaca.
- Pengguna boleh tanda satu mesej atau semua mesej sebagai dibaca.
- Pemberitahuan baru sync melalui Supabase dan tidak memerlukan upgrade APK setiap kali Admin menghantar mesej.
- About/Profil memaparkan AVIA v6.9f.

## v6.9g - Password sementara / reset
- Admin cipta staf -> AVIA memaparkan ID Login + Password Sementara.
- Akaun baharu ditanda `must_change_password=true`.
- Login pertama memaksa staf menukar password sendiri.
- Admin boleh `Reset Password`; sistem jana password sementara baharu.
- Password sebenar selepas ditukar tidak dipaparkan kepada admin.
- Deploy Edge Function `admin-reset-password`.
- Run `supabase/migration_v6_9g_password_flow.sql`.

## v6.9i - Login Biometrik
- Pengguna login biasa sekurang-kurangnya sekali.
- Di Profil, pilih `Aktifkan Biometrik`.
- Android akan meminta pengesahan cap jari/biometrik.
- Selepas diaktifkan, jika session AVIA masih sah, membuka app akan memaparkan skrin biometrik terlebih dahulu.
- `Guna ID & Password` kekal sebagai fallback.
- AVIA tidak menerima atau menyimpan data cap jari. Pengesahan dibuat oleh sistem Android.
- Biometrik native memerlukan Android 9 (API 28) atau lebih baharu.
- Demo/browser biasa tidak mempunyai biometric native Android; gunakan APK pada telefon untuk ujian sebenar.

## v6.9j - Masa pilihan untuk pergerakan
- Update Status kini mempunyai Masa Mula dan Masa Tamat sebagai medan pilihan.
- Jika masa dikosongkan, status dianggap sepanjang hari.
- Jika masa diisi, Dashboard Hari Ini hanya menukar status apabila waktu berkenaan tiba.
- Contoh 14:00-17:00: sebelum 14:00 staf kekal Di Pejabat; 14:00-17:00 dipaparkan Keluar Pejabat; selepas 17:00 kembali Di Pejabat.
- Masa dipaparkan bersama status dan boleh diedit.

## v6.9k - Hari Lahir
- Admin boleh simpan hari dan bulan lahir staf sahaja; tahun/umur tidak diperlukan.
- Pilihan `Paparkan hari lahir dalam AVIA` boleh ditutup bagi staf yang tidak mahu dipaparkan.
- Dashboard memaparkan hari lahir hari ini dan senarai akan datang sehingga 7 hari.
- Footer `© 2026 Jabatan Digital Negara (JDN)` dibuang sementara menunggu reka bentuk identiti baharu.
- Run `supabase/migration_v6_9k_birthdays.sql` untuk mod Supabase.

## v6.9l - Pentadbiran & Pilot Readiness
Tambahan:
- Import staf CSV (Demo; akaun Supabase penuh kekal melalui Edge Function demi keselamatan).
- Pemberitahuan boleh Pin dan mempunyai tarikh luput.
- Status versi aplikasi / `Update Available` indicator.
- Arkib staf tanpa perlu delete rekod.
- Bulk tukar unit.
- Kad `Siapa Tiada Hari Ini`.
- Backup / Restore data Demo dalam JSON.
- Audit demo diperkemas dengan tindakan pentadbiran.
- Empty/error state bila sync gagal.
- Paparan `Last Successful Sync`.
- Run `supabase/migration_v6_9l_admin_tools.sql`.

## v6.9m - Weekend/Public Holiday Presence Fix
- Pada Sabtu, Ahad dan Cuti Umum, `Status Hari Ini` kekal `—`.
- Bahagian `Ada di Pejabat` tidak lagi memaparkan nama staf.
- Diganti dengan mesej `Hari tidak bekerja – status kehadiran tidak dipaparkan.`
- `Siapa Tiada Hari Ini` juga tidak membuat andaian pergerakan pada hari tidak bekerja.

## v6.9n - Demo Dashboard Dataset
- Demo Offline kini mempunyai 20 orang (Admin Demo + 19 staf biasa).
- 3 unit: UNIT IT, UNIT PENTADBIRAN, UNIT DATA.
- Data contoh merangkumi Cuti Rehat, MC, Mesyuarat/Bengkel luar pejabat, urusan Klinik, Kursus Dalaman dan Kuarantin.
- Demo Preview Date disediakan supaya dashboard boleh diuji walaupun aplikasi dibuka pada Sabtu/Ahad.
- Tarikh preview awal: Isnin, 21 September 2026.
- Data ini hanya untuk melihat output/dashboard dan tidak memberi kesan kepada Supabase production.

## v6.9o - Demo Birthday Data
- Demo mempunyai tepat 2 staf dengan hari lahir pada September 2026.
- Hakim Azlan: 21 September.
- Azieffah Karim: 26 September.
- Dashboard birthday boleh diuji bersama Preview Dashboard Demo.
