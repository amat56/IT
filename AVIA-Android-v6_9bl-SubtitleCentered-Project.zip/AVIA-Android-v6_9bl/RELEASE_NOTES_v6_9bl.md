# AVIA v6.9bl

- Subtitle di bawah wordmark AVIA kini center-aligned.
- Kekal 2 baris: Availability & Visibility / Information Application.
- Saiz subtitle kekal 8px.
- Organisasi UNIT IT kekal 8px di bawah Jata Negara.
- Semua fungsi v6.9bk dikekalkan.
