# AVIA v6.9bh
- Betulkan susun atur header: Jata Negara dan organisasi di sebelah kiri.
- Logo AVIA serta subtitle dua baris kekal di sebelah kanan.
- Organisasi tidak lagi dipaparkan di bawah logo AVIA.
- Sumber Jata menggunakan SVG dengan fallback PNG jika SVG gagal dimuat.
