# AVIA v6.9bk

- Subtitle header dikecilkan kepada 8px.
- Nama organisasi di bawah Jata dikecilkan kepada 8px.
- Kad Waktu Solat dipindahkan ke bawah Quick Status pada dashboard Hari Ini.
- Semua fungsi v6.9bj dikekalkan.
