package my.gov.demo.myunit;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Looper;
import android.app.KeyguardManager;
import android.content.Context;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private CancellationSignal cancellationSignal;
    private static final int LOCATION_PERMISSION_REQUEST = 2001;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        webView.addJavascriptInterface(new BiometricBridge(), "AndroidBiometric");
        webView.addJavascriptInterface(new LocationBridge(), "AndroidLocation");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                deliverDeepLink(getIntent());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }


    private void deliverDeepLink(Intent intent) {
        if (intent == null || intent.getData() == null || webView == null) return;
        Uri data = intent.getData();
        String url = data.toString();
        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
        webView.evaluateJavascript("window.onAviaDeepLink && window.onAviaDeepLink('" + safe + "');", null);
        intent.setData(null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        deliverDeepLink(intent);
    }

    private void sendBiometricResult(final boolean ok, final String message) {
        runOnUiThread(() -> {
            String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'");
            webView.evaluateJavascript(
                "window.onBiometricResult && window.onBiometricResult(" + ok + ",'" + safe + "');",
                null
            );
        });
    }

    private void sendLocationResult(final Location loc) {
        if (loc == null || webView == null) { sendLocationError("Lokasi telefon tidak dapat dikesan. Gunakan zon JAKIM manual."); return; }
        final double lat = loc.getLatitude(), lon = loc.getLongitude();
        runOnUiThread(() -> webView.evaluateJavascript("window.onAviaLocation && window.onAviaLocation(" + lat + "," + lon + ");", null));
    }
    private void sendLocationError(final String message) {
        runOnUiThread(() -> { String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'"); webView.evaluateJavascript("window.onAviaLocationError && window.onAviaLocationError('" + safe + "');", null); });
    }
    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private Location bestLastKnownLocation() {
        if (!hasLocationPermission() || locationManager == null) return null; Location best = null;
        try { for (String provider : locationManager.getProviders(true)) { Location l = locationManager.getLastKnownLocation(provider); if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) best = l; } } catch (SecurityException ignored) {}
        return best;
    }
    private void requestDeviceLocation() {
        if (!hasLocationPermission()) { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST); return; }
        Location cached = bestLastKnownLocation();
        if (cached != null && System.currentTimeMillis() - cached.getTime() < 10 * 60 * 1000) { sendLocationResult(cached); return; }
        if (locationManager == null) { sendLocationError("Servis lokasi tidak tersedia."); return; }
        try {
            String provider = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ? LocationManager.NETWORK_PROVIDER : LocationManager.GPS_PROVIDER;
            locationManager.requestSingleUpdate(provider, new LocationListener() {
                @Override public void onLocationChanged(Location location) { sendLocationResult(location); }
                @Override public void onProviderDisabled(String provider) { sendLocationError("Lokasi telefon dimatikan. Aktifkan Location/GPS atau pilih zon manual."); }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
            }, Looper.getMainLooper());
        } catch (Exception e) { if (cached != null) sendLocationResult(cached); else sendLocationError("Lokasi telefon tidak dapat dikesan. Aktifkan Location/GPS atau pilih zon manual."); }
    }
    public class LocationBridge { @JavascriptInterface public void requestLocation() { runOnUiThread(() -> requestDeviceLocation()); } }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) { if (hasLocationPermission()) requestDeviceLocation(); else sendLocationError("Kebenaran lokasi tidak diberikan. Pilih zon JAKIM secara manual."); }
    }

    public class BiometricBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P;
        }

        @JavascriptInterface
        public void authenticate() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                    sendBiometricResult(false, "Biometrik memerlukan Android 9 atau lebih baharu.");
                    return;
                }

                try {
                    cancellationSignal = new CancellationSignal();
                    Executor executor = getMainExecutor();

                    BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
                        .setTitle("AVIA")
                        .setSubtitle("Sahkan identiti untuk membuka AVIA")
                        .setDescription("Gunakan cap jari / biometrik yang didaftarkan pada telefon ini.")
                        .setNegativeButton("Guna ID & Password", executor, (dialog, which) ->
                            sendBiometricResult(false, "Gunakan ID dan password.")
                        )
                        .build();

                    prompt.authenticate(
                        cancellationSignal,
                        executor,
                        new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                super.onAuthenticationSucceeded(result);
                                sendBiometricResult(true, "Pengesahan berjaya.");
                            }

                            @Override
                            public void onAuthenticationError(int errorCode, CharSequence errString) {
                                super.onAuthenticationError(errorCode, errString);
                                sendBiometricResult(false, errString == null ? "Pengesahan gagal." : errString.toString());
                            }

                            @Override
                            public void onAuthenticationFailed() {
                                super.onAuthenticationFailed();
                                sendBiometricResult(false, "Biometrik tidak sepadan. Cuba lagi.");
                            }
                        }
                    );
                } catch (Exception e) {
                    sendBiometricResult(false, "Biometrik tidak tersedia pada peranti ini.");
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (cancellationSignal != null) cancellationSignal.cancel();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
