# AVIA v6.9bj - Header Organisation Alignment

- UNIT IT moved directly below Jata Negara on the left side of the header.
- AVIA wordmark and two-line subtitle remain on the right.
- Carries forward v6.9bi prayer-time active highlighting and earlier features.
