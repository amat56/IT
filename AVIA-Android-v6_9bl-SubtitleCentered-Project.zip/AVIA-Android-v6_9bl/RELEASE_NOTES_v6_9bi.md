# AVIA v6.9bi

Waktu Solat:
- Kotak waktu solat semasa bertukar hijau secara automatik.
- Contoh: selepas masuk Zohor, kotak Zohor berwarna hijau sehingga masuk Asar.
- Berlaku sama untuk Subuh, Asar, Maghrib dan Isyak.
- Penentuan masa menggunakan waktu Malaysia `Asia/Kuala_Lumpur` (UTC+8).
- Paparan disemak semula setiap 30 saat tanpa perlu buka semula aplikasi.
