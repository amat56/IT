# AVIA v6.9bf - Auto Waktu Solat JAKIM

- Auto Detect lokasi telefon menggunakan GPS/koordinat.
- Koordinat dipadankan kepada zon waktu solat Malaysia.
- Waktu solat cuba diambil terus daripada e-Solat JAKIM.
- Jika endpoint rasmi gagal, fallback menggunakan solat.my yang menyajikan data JAKIM.
- Admin boleh memilih zon JAKIM manual jika lokasi ditolak/tidak tersedia.
- Input manual waktu solat dibuang.
- Cuti umum terdekat sentiasa memaparkan cuti seterusnya tanpa had 45 hari.
