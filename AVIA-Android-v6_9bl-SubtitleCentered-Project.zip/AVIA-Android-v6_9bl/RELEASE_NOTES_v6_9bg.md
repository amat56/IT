# AVIA v6.9bg

Kemasan header:
- Tulisan AVIA di sebelah kiri dibuang.
- Sebelah kiri kini memaparkan Jata Negara Malaysia.
- Wordmark AVIA kekal di sebelah kanan.
- Subtitle dipindahkan ke bawah wordmark AVIA dan dipaksa dua baris:
  1. Availability & Visibility
  2. Information Application
- Organisasi kekal dipaparkan kecil di bawah subtitle.
- Jata dan wordmark disejajarkan dalam header.

Nota aset Jata:
- Header menggunakan imej Jata Negara yang dirujuk kepada reka bentuk kerajaan Malaysia dan dimuat melalui sumber Wikimedia Commons.
- Jika mahu operasi 100% offline, aset PNG rasmi organisasi boleh dibundel terus dalam versi seterusnya.
