package my.gov.demo.myunit;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private CancellationSignal cancellationSignal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new BiometricBridge(), "AndroidBiometric");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void sendBiometricResult(final boolean ok, final String message) {
        runOnUiThread(() -> {
            String safe = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'");
            webView.evaluateJavascript(
                "window.onBiometricResult && window.onBiometricResult(" + ok + ",'" + safe + "');",
                null
            );
        });
    }

    public class BiometricBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P;
        }

        @JavascriptInterface
        public void authenticate() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                    sendBiometricResult(false, "Biometrik memerlukan Android 9 atau lebih baharu.");
                    return;
                }

                try {
                    cancellationSignal = new CancellationSignal();
                    Executor executor = getMainExecutor();

                    BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
                        .setTitle("AVIA")
                        .setSubtitle("Sahkan identiti untuk membuka AVIA")
                        .setDescription("Gunakan cap jari / biometrik yang didaftarkan pada telefon ini.")
                        .setNegativeButton("Guna ID & Password", executor, (dialog, which) ->
                            sendBiometricResult(false, "Gunakan ID dan password.")
                        )
                        .build();

                    prompt.authenticate(
                        cancellationSignal,
                        executor,
                        new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                super.onAuthenticationSucceeded(result);
                                sendBiometricResult(true, "Pengesahan berjaya.");
                            }

                            @Override
                            public void onAuthenticationError(int errorCode, CharSequence errString) {
                                super.onAuthenticationError(errorCode, errString);
                                sendBiometricResult(false, errString == null ? "Pengesahan gagal." : errString.toString());
                            }

                            @Override
                            public void onAuthenticationFailed() {
                                super.onAuthenticationFailed();
                                sendBiometricResult(false, "Biometrik tidak sepadan. Cuba lagi.");
                            }
                        }
                    );
                } catch (Exception e) {
                    sendBiometricResult(false, "Biometrik tidak tersedia pada peranti ini.");
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (cancellationSignal != null) cancellationSignal.cancel();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
